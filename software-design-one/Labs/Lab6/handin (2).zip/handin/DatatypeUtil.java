public class DatatypeUtil{
	
	public static String getType(double data){ 
		String dataType = "double";
		return dataType;
	}
	public static String getType(float data){
		String dataType = "float";
		return dataType; 
	}
	public static String getType(int data){
		String dataType = "int";
		return dataType;
	}
	public static String getType(long data){
		String dataType = "long";
		return dataType;
	}
	public static String getType(char data){
		String dataType = "char";
		return dataType;
	}
	public static String getType(boolean data){
		String dataType = "boolean";
		return dataType;
	}
	public static String getType(String data){
		String dataType = "String";
		return dataType;
	}
}