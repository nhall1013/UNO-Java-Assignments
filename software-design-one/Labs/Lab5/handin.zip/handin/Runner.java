public class Runner{

	public static void main(String[] args){
		System.out.println(Temperature.celsiusToFahrenheit(1.0)); 
		System.out.println(Temperature.celsiusToKelvin(1.0));
		System.out.println(Temperature.fahrenheitToCelsius(1.0));
		System.out.println(Temperature.fahrenheitToKelvin(1.0));
		System.out.println(Temperature.kelvinToFahrenheit(1.0));
		System.out.println(Temperature.kelvinToCelsius(1.0));
	}
}