public class Monster{
	
}