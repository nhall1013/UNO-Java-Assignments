import java.util.Observable;
import java.util.Observer;

public class RegularShapeMonitor implements Observer{

	@Override
	public void update(Observable arg0, Object arg1) {
		//#TODO
		//hint, you don't need to do anything with arg1
		
	}

}
