import java.util.Observable;
import java.util.Observer;

public class RegularShapeMonitor implements Observer{
	RegularShape shape;
	
	@Override
	public void update(Observable arg0, Object arg1) {
		//#TODO
		//hint, you don't need to do anything with arg1
		shape = (RegularShape) arg0;
		
		if(shape.getEdgeLength() == 0){
			System.out.println("Warning! Your shape has edges of length 0!\nNew Area:" + " " + shape.getArea());
		}
		
		if(shape.getEdgeLength() > 0){
			System.out.println("Length of edges has changed. Recalculating Area.\nNew Area:" + " " + shape.getArea());
		}
	}

}
