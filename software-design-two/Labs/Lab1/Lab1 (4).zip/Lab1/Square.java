import java.lang.Math;
public class Square extends RegularShape{

	public Square(int edgeLength){
		super(4,edgeLength);
	
	}
	
	@Override
	public void calculateArea(){
		this.area = Math.pow(getEdgeLength(),2);
	}

}